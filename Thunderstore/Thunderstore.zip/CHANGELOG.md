## 1.0.1

- First release
- Update Dependencies
