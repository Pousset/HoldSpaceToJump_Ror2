# My HoldSpaceMod

HoldSpaceMod adds an improved "hold space to auto-jump" mechanic to Risk of Rain 2. Instead of instantly triggering auto-jump, the mod distinguishes between a short tap and a long press of the Space key.
